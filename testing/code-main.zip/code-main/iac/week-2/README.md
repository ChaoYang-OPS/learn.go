# Getting Started
```
terraform init
export TF_VAR_secret_id=
export TF_VAR_secret_key=
terraform apply -auto-approve
```