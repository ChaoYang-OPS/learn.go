# Demo

1. build nginx image

```
docker build -t nginx -f Dockerfile .
```

