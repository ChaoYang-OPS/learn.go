key password: password123

docker buildx build --push --platform=linux/amd64 --tag lyzhang1999/cosign:latest -f Dockerfile .